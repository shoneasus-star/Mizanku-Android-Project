package id.dzikr.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.content.Context;
import android.view.Window;

public class MainActivity extends Activity {
    private WebView webView;
    private Vibrator vibrator;

    @SuppressWarnings("deprecation")
    private Vibrator getDeviceVibrator() {
        if (vibrator != null) return vibrator;
        if (Build.VERSION.SDK_INT >= 31) {
            VibratorManager manager = (VibratorManager) getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            vibrator = manager != null ? manager.getDefaultVibrator() : null;
        } else {
            vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        }
        return vibrator;
    }

    public class AndroidVibratorBridge {
        @JavascriptInterface
        public boolean hasVibrator() {
            Vibrator v = getDeviceVibrator();
            return v != null && v.hasVibrator();
        }

        @JavascriptInterface
        public boolean vibrate(String pattern) {
            try {
                Vibrator v = getDeviceVibrator();
                if (v == null || !v.hasVibrator() || pattern == null) return false;
                String[] parts = pattern.split(",");
                long[] timings = new long[parts.length];
                for (int i = 0; i < parts.length; i++) {
                    timings[i] = Math.max(0L, Math.min(5000L, Long.parseLong(parts[i].trim())));
                }
                if (timings.length == 1) {
                    if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(Math.max(1L, timings[0]), VibrationEffect.DEFAULT_AMPLITUDE));
                    else v.vibrate(Math.max(1L, timings[0]));
                } else {
                    if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(timings, -1));
                    else v.vibrate(timings, -1);
                }
                return true;
            } catch (Exception ignored) { return false; }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(15, 118, 110));
        window.setNavigationBarColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AndroidVibratorBridge(), "AndroidVibrator");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        setContentView(webView);

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/www/index.html");
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidVibrator");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
