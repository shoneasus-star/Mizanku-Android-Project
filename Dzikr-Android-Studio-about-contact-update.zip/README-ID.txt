# Dzikr Android Studio

Proyek Android native sederhana yang menampilkan aplikasi web Dzikr asli melalui WebView.
Folder HTML, manifest PWA, service worker, dan ikon sumber disertakan di:
`app/src/main/assets/www/`.

## Membuat APK
1. Ekstrak ZIP ini.
2. Buka Android Studio.
3. Pilih **Open** lalu pilih folder `Dzikr-Android-Studio` (folder yang berisi `settings.gradle`).
4. Tunggu Gradle Sync. Pastikan koneksi internet tersedia agar Android Gradle Plugin dan Android SDK yang diperlukan dapat diunduh.
5. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
- Aplikasi web asli ditempatkan sebagai aset lokal sehingga konten utamanya tersedia tanpa internet.
- Izin INTERNET disertakan untuk kebutuhan konten eksternal yang mungkin digunakan halaman (misalnya Google Fonts).
- Service Worker PWA tidak dijalankan pada skema `file://` WebView; mode offline aplikasi Android ini mengandalkan aset yang dibundel di APK.
- Package name: `id.dzikr.app`; version: `1.0` (versionCode 1).
- Proyek ini adalah sumber siap dibuka di Android Studio, bukan APK yang sudah dikompilasi.
